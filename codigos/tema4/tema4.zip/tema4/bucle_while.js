//Declarando el bucle while
let contador = 1;
while (contador < 10) {
    console.log(contador);
    contador += 1;
}

