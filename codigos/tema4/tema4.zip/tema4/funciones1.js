function saludo(nombre) {
    return `Hola ${nombre}`;
}

console.log(saludo("Luciana"));
