//Declarando objetos
const objeto = {
    nombre: "Miguel",
    apellido: "Gomez",
    edad: 25,
    pasatiempos: [],
    direccion: {}
};

//Acceddiendo a los objetos
let acceso = objeto.nombre;
console.log(acceso);
